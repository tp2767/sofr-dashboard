# SOFR Volatility Dashboard

Live daily volatility monitor for SOFR forward swaps and futures.

## What it does

- Uploads your daily Bloomberg Excel export each morning
- Calculates 20-day rolling standard deviation for all 7 instruments
- Ranks instruments from most to least volatile
- Flags anything above 2x baseline as statistically elevated
- Shows full history charts with 2SD threshold marked

## Instruments tracked

**Swaps:** 1Y1Y, 2Y2Y, 5Y5Y, 10Y10Y  
**Futures:** SFR5, SFR9, SFR13

## How to deploy on Streamlit Cloud (5 minutes)

1. Create a free account at https://streamlit.io
2. Create a new GitHub repository (free at github.com)
3. Upload these two files to the repo:
   - app.py
   - requirements.txt
4. Go to share.streamlit.io → New app
5. Connect your GitHub repo, set main file to app.py
6. Click Deploy — you get a shareable URL in ~2 minutes

## Daily workflow

1. Open Bloomberg Excel each morning
2. Hit Ctrl+Alt+F9 to refresh all BDH formulas
3. Save as SOFR_Volatility_Analysis.xlsx
4. Open the dashboard URL
5. Upload the file — dashboard updates instantly

## Data format expected

Excel file with 7 sheets named exactly:
1Y1Y, 2Y2Y, 5Y5Y, 10Y10Y, SFR5, SFR9, SFR13

Each sheet: columns 13-17 (Date, Close, Change, High, Low)
