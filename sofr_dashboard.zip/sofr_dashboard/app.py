import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import io

# ── Page config ────────────────────────────────────────────────────
st.set_page_config(
    page_title="SOFR Volatility Dashboard",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# ── Custom CSS ─────────────────────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;600;700&display=swap');

    html, body, [class*="css"] {
        font-family: 'IBM Plex Sans', sans-serif;
    }

    .stApp {
        background-color: #0a0e1a;
        color: #e8eaf0;
    }

    .main-header {
        font-family: 'IBM Plex Mono', monospace;
        font-size: 11px;
        color: #4a9eff;
        letter-spacing: 3px;
        text-transform: uppercase;
        padding: 8px 0 4px 0;
        border-bottom: 1px solid #1e2a3a;
        margin-bottom: 4px;
    }

    .main-title {
        font-family: 'IBM Plex Sans', sans-serif;
        font-size: 32px;
        font-weight: 700;
        color: #ffffff;
        line-height: 1.1;
        margin-bottom: 2px;
    }

    .main-subtitle {
        font-family: 'IBM Plex Mono', monospace;
        font-size: 11px;
        color: #5a7a9a;
        margin-bottom: 24px;
    }

    .metric-card {
        background: #0f1520;
        border: 1px solid #1e2a3a;
        border-radius: 6px;
        padding: 16px 20px;
        margin-bottom: 12px;
        transition: border-color 0.2s;
    }

    .metric-card:hover {
        border-color: #4a9eff;
    }

    .metric-label {
        font-family: 'IBM Plex Mono', monospace;
        font-size: 10px;
        color: #5a7a9a;
        letter-spacing: 2px;
        text-transform: uppercase;
        margin-bottom: 6px;
    }

    .metric-value {
        font-family: 'IBM Plex Mono', monospace;
        font-size: 28px;
        font-weight: 600;
        color: #ffffff;
        line-height: 1;
    }

    .metric-sub {
        font-family: 'IBM Plex Mono', monospace;
        font-size: 11px;
        color: #5a7a9a;
        margin-top: 4px;
    }

    .alert-high {
        background: #1a0f0f;
        border: 1px solid #ff4444;
        border-left: 3px solid #ff4444;
        border-radius: 4px;
        padding: 12px 16px;
        margin: 8px 0;
    }

    .alert-elevated {
        background: #1a140f;
        border: 1px solid #ff8c00;
        border-left: 3px solid #ff8c00;
        border-radius: 4px;
        padding: 12px 16px;
        margin: 8px 0;
    }

    .alert-normal {
        background: #0f1a0f;
        border: 1px solid #00cc66;
        border-left: 3px solid #00cc66;
        border-radius: 4px;
        padding: 12px 16px;
        margin: 8px 0;
    }

    .alert-text {
        font-family: 'IBM Plex Mono', monospace;
        font-size: 12px;
        color: #e8eaf0;
    }

    .section-header {
        font-family: 'IBM Plex Mono', monospace;
        font-size: 10px;
        color: #4a9eff;
        letter-spacing: 3px;
        text-transform: uppercase;
        border-bottom: 1px solid #1e2a3a;
        padding-bottom: 8px;
        margin: 24px 0 16px 0;
    }

    .rank-table th {
        font-family: 'IBM Plex Mono', monospace;
        font-size: 10px;
        color: #5a7a9a;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .stFileUploader {
        background: #0f1520;
        border: 1px dashed #1e2a3a;
        border-radius: 6px;
        padding: 12px;
    }

    .timestamp {
        font-family: 'IBM Plex Mono', monospace;
        font-size: 10px;
        color: #2a4a6a;
    }

    div[data-testid="stMetric"] {
        background: #0f1520;
        border: 1px solid #1e2a3a;
        border-radius: 6px;
        padding: 16px;
    }

    div[data-testid="stMetric"] label {
        font-family: 'IBM Plex Mono', monospace;
        font-size: 10px !important;
        color: #5a7a9a !important;
        letter-spacing: 2px;
        text-transform: uppercase;
    }

    div[data-testid="stMetric"] div[data-testid="stMetricValue"] {
        font-family: 'IBM Plex Mono', monospace;
        color: #ffffff;
    }

    .stDataFrame {
        background: #0f1520;
    }

    footer {visibility: hidden;}
    #MainMenu {visibility: hidden;}
    header {visibility: hidden;}
</style>
""", unsafe_allow_html=True)

INSTRUMENTS = ['1Y1Y','2Y2Y','5Y5Y','10Y10Y','SFR5','SFR9','SFR13']
IS_FUTURES = lambda x: x in ['SFR5','SFR9','SFR13']

COLORS = {
    '1Y1Y':   '#4a9eff',
    '2Y2Y':   '#00ccff',
    '5Y5Y':   '#00cc66',
    '10Y10Y': '#ffaa00',
    'SFR5':   '#ff4444',
    'SFR9':   '#ff88aa',
    'SFR13':  '#cc44ff',
}

# ── Data processing ────────────────────────────────────────────────
@st.cache_data
def process_data(file_bytes):
    xl = pd.ExcelFile(io.BytesIO(file_bytes))
    all_data = {}
    for inst in INSTRUMENTS:
        if inst not in xl.sheet_names:
            continue
        df = pd.read_excel(io.BytesIO(file_bytes), sheet_name=inst, header=None)
        clean = df.iloc[1:, 12:17].copy()
        clean.columns = ['Date','Close','Change','High','Low']
        clean['Date'] = pd.to_datetime(clean['Date'], errors='coerce')
        for c in ['Close','Change','High','Low']:
            clean[c] = pd.to_numeric(clean[c], errors='coerce')
        clean = clean.dropna(subset=['Date','Close'])
        clean = clean.set_index('Date').sort_index()
        if IS_FUTURES(inst):
            clean['Close'] = 100 - clean['Close']
        clean['DailyReturn'] = clean['Close'].diff() * 100
        clean['Roll20Std']   = clean['DailyReturn'].rolling(20).std()
        baseline             = clean['DailyReturn'].std()
        clean['NormVol']     = clean['Roll20Std'] / baseline
        clean['Baseline']    = baseline
        all_data[inst] = clean
    return all_data

def get_today_snapshot(all_data):
    rows = []
    for inst in INSTRUMENTS:
        if inst not in all_data:
            continue
        d = all_data[inst]
        last = d.dropna(subset=['Roll20Std']).iloc[-1]
        baseline = last['Baseline']
        norm     = last['NormVol']
        roll_bps = last['Roll20Std']
        date     = d.dropna(subset=['Roll20Std']).index[-1]

        if norm >= 3.0:
            status = '🔴 EXTREME'
        elif norm >= 2.0:
            status = '🟠 ELEVATED'
        elif norm >= 1.5:
            status = '🟡 ABOVE NORMAL'
        else:
            status = '🟢 NORMAL'

        rows.append({
            'Instrument': inst,
            'Type': 'Futures' if IS_FUTURES(inst) else 'Swap',
            'As Of': date.strftime('%Y-%m-%d'),
            '20D Std Dev (bps)': round(roll_bps, 2),
            'Baseline (bps)': round(baseline, 2),
            'SD Multiple (x)': round(norm, 2),
            'Status': status,
        })
    df = pd.DataFrame(rows).sort_values('SD Multiple (x)', ascending=False).reset_index(drop=True)
    df.index = df.index + 1
    return df

# ── Header ─────────────────────────────────────────────────────────
st.markdown('<div class="main-header">South Street Securities — Rates Desk</div>', unsafe_allow_html=True)
st.markdown('<div class="main-title">SOFR Volatility Dashboard</div>', unsafe_allow_html=True)
st.markdown(f'<div class="main-subtitle">20-Day Rolling Volatility Monitor | {datetime.now().strftime("%A, %B %d, %Y")}</div>', unsafe_allow_html=True)

# ── Upload ─────────────────────────────────────────────────────────
st.markdown('<div class="section-header">Daily Data Upload</div>', unsafe_allow_html=True)

col_up, col_info = st.columns([2, 3])
with col_up:
    uploaded = st.file_uploader(
        "Upload Bloomberg Excel export",
        type=['xlsx'],
        help="Upload the SOFR_Volatility_Analysis.xlsx file exported from Bloomberg each morning"
    )
with col_info:
    st.markdown("""
    <div style="background:#0f1520; border:1px solid #1e2a3a; border-radius:6px; padding:16px; margin-top:8px;">
        <div style="font-family:'IBM Plex Mono',monospace; font-size:10px; color:#5a7a9a; letter-spacing:2px; text-transform:uppercase; margin-bottom:8px;">How to update</div>
        <div style="font-family:'IBM Plex Sans',sans-serif; font-size:12px; color:#a0b0c0; line-height:1.8;">
            1. Open Bloomberg Excel each morning<br>
            2. Refresh the BDH data (Ctrl+Alt+F9)<br>
            3. Save the file<br>
            4. Upload it here — dashboard updates instantly
        </div>
    </div>
    """, unsafe_allow_html=True)

if uploaded is None:
    st.markdown("""
    <div style="text-align:center; padding:60px 0; color:#2a4a6a;">
        <div style="font-family:'IBM Plex Mono',monospace; font-size:32px; margin-bottom:12px;">📊</div>
        <div style="font-family:'IBM Plex Mono',monospace; font-size:12px; letter-spacing:2px;">AWAITING DATA UPLOAD</div>
        <div style="font-family:'IBM Plex Sans',sans-serif; font-size:12px; margin-top:8px; color:#1e3a5a;">Upload your Bloomberg export above to load the dashboard</div>
    </div>
    """, unsafe_allow_html=True)
    st.stop()

# ── Process data ───────────────────────────────────────────────────
with st.spinner("Processing..."):
    all_data = process_data(uploaded.read())

snapshot = get_today_snapshot(all_data)
most_volatile = snapshot.iloc[0]

# ── Top alert ─────────────────────────────────────────────────────
norm_val = most_volatile['SD Multiple (x)']
if norm_val >= 3.0:
    alert_class = "alert-high"
    alert_icon = "⚠️"
elif norm_val >= 2.0:
    alert_class = "alert-elevated"
    alert_icon = "📈"
else:
    alert_class = "alert-normal"
    alert_icon = "✓"

st.markdown(f"""
<div class="{alert_class}">
    <div class="alert-text">
        {alert_icon} &nbsp;
        <strong>MOST VOLATILE TODAY: {most_volatile['Instrument']}</strong>
        &nbsp;—&nbsp;
        {most_volatile['20D Std Dev (bps)']} bps &nbsp;|&nbsp;
        {most_volatile['SD Multiple (x)']}x baseline &nbsp;|&nbsp;
        {most_volatile['Status']} &nbsp;|&nbsp;
        As of {most_volatile['As Of']}
    </div>
</div>
""", unsafe_allow_html=True)

# ── Key metrics row ────────────────────────────────────────────────
st.markdown('<div class="section-header">Today\'s Snapshot</div>', unsafe_allow_html=True)

cols = st.columns(7)
for i, (_, row) in enumerate(snapshot.iterrows()):
    with cols[i-1]:
        color = '#ff4444' if row['SD Multiple (x)'] >= 3 else \
                '#ff8c00' if row['SD Multiple (x)'] >= 2 else \
                '#ffaa00' if row['SD Multiple (x)'] >= 1.5 else '#00cc66'
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">{row['Instrument']}</div>
            <div class="metric-value" style="color:{color}; font-size:22px;">{row['SD Multiple (x)']}x</div>
            <div class="metric-sub">{row['20D Std Dev (bps)']} bps</div>
            <div class="metric-sub" style="font-size:9px; margin-top:4px;">{row['Status'].split(' ',1)[1] if ' ' in row['Status'] else row['Status']}</div>
        </div>
        """, unsafe_allow_html=True)

# ── Ranking table ──────────────────────────────────────────────────
st.markdown('<div class="section-header">Volatility Ranking — Most to Least Volatile</div>', unsafe_allow_html=True)

display_df = snapshot[['Instrument','Type','20D Std Dev (bps)','Baseline (bps)','SD Multiple (x)','Status','As Of']].copy()

def color_sd(val):
    if val >= 3.0:
        return 'color: #ff4444; font-weight: bold'
    elif val >= 2.0:
        return 'color: #ff8c00; font-weight: bold'
    elif val >= 1.5:
        return 'color: #ffaa00'
    return 'color: #00cc66'

styled = display_df.style.applymap(color_sd, subset=['SD Multiple (x)'])
st.dataframe(styled, use_container_width=True, height=310)

# ── Charts ─────────────────────────────────────────────────────────
st.markdown('<div class="section-header">Rolling Volatility History</div>', unsafe_allow_html=True)

tab1, tab2, tab3 = st.tabs(["All Instruments", "Swaps", "Futures"])

def make_vol_chart(inst_list, title):
    fig = go.Figure()
    for inst in inst_list:
        if inst not in all_data:
            continue
        d = all_data[inst]['NormVol'].dropna()
        fig.add_trace(go.Scatter(
            x=d.index, y=d.values,
            name=inst,
            line=dict(color=COLORS[inst], width=1.8),
            hovertemplate=f'<b>{inst}</b><br>%{{x|%b %d, %Y}}<br>%{{y:.2f}}x baseline<extra></extra>'
        ))
    # 1x and 2x lines
    fig.add_hline(y=1.0, line_dash='dash', line_color='#2a4a6a',
                  annotation_text='Baseline (1.0x)', annotation_position='left',
                  annotation_font_color='#2a4a6a', annotation_font_size=10)
    fig.add_hline(y=2.0, line_dash='dot', line_color='#ff4444',
                  annotation_text='2SD Threshold (2.0x)', annotation_position='left',
                  annotation_font_color='#ff4444', annotation_font_size=10)
    # Shade above 2x
    fig.add_hrect(y0=2.0, y1=10, fillcolor='rgba(255,68,68,0.05)', line_width=0)

    fig.update_layout(
        title=dict(text=title, font=dict(family='IBM Plex Mono', size=13, color='#e8eaf0')),
        plot_bgcolor='#0a0e1a',
        paper_bgcolor='#0a0e1a',
        font=dict(family='IBM Plex Mono', color='#5a7a9a'),
        xaxis=dict(
            gridcolor='#1e2a3a', tickformat='%b %Y',
            tickfont=dict(size=10), showgrid=True, zeroline=False
        ),
        yaxis=dict(
            gridcolor='#1e2a3a', title='Volatility (x Baseline)',
            tickfont=dict(size=10), showgrid=True, zeroline=False
        ),
        legend=dict(
            bgcolor='rgba(0,0,0,0)', bordercolor='#1e2a3a',
            font=dict(size=10), orientation='h',
            yanchor='bottom', y=1.02, xanchor='left', x=0
        ),
        hovermode='x unified',
        height=420,
        margin=dict(l=50, r=20, t=60, b=50)
    )
    return fig

with tab1:
    st.plotly_chart(make_vol_chart(INSTRUMENTS, '20-Day Rolling Volatility — All Instruments'),
                    use_container_width=True)

with tab2:
    st.plotly_chart(make_vol_chart(['1Y1Y','2Y2Y','5Y5Y','10Y10Y'],
                                    '20-Day Rolling Volatility — SOFR Forward Swaps'),
                    use_container_width=True)

with tab3:
    st.plotly_chart(make_vol_chart(['SFR5','SFR9','SFR13'],
                                    '20-Day Rolling Volatility — SOFR Futures Implied Rates'),
                    use_container_width=True)

# ── Historical peaks table ─────────────────────────────────────────
st.markdown('<div class="section-header">Historical Peak Volatility Windows</div>', unsafe_allow_html=True)

peak_rows = []
for inst in INSTRUMENTS:
    if inst not in all_data:
        continue
    d = all_data[inst]
    peak_end = d['NormVol'].idxmax()
    idx_loc  = d.index.get_loc(peak_end)
    peak_start = d.index[max(0, idx_loc - 19)]
    peak_val   = d['NormVol'].max()
    peak_bps   = d['Roll20Std'].max()
    peak_rows.append({
        'Instrument': inst,
        'Peak Window Start': peak_start.strftime('%Y-%m-%d'),
        'Peak Window End':   peak_end.strftime('%Y-%m-%d'),
        'Peak SD Multiple':  round(peak_val, 2),
        'Peak 20D Std Dev (bps)': round(peak_bps, 2),
    })

peak_df = pd.DataFrame(peak_rows).sort_values('Peak SD Multiple', ascending=False)
st.dataframe(peak_df.style.applymap(color_sd, subset=['Peak SD Multiple']),
             use_container_width=True, height=310)

# ── Footer ─────────────────────────────────────────────────────────
st.markdown(f"""
<div style="margin-top:48px; border-top:1px solid #1e2a3a; padding-top:12px;">
    <div class="timestamp">
        South Street Securities — Rates Desk &nbsp;|&nbsp;
        SOFR Volatility Dashboard &nbsp;|&nbsp;
        Data: Bloomberg Terminal &nbsp;|&nbsp;
        Last refreshed: {datetime.now().strftime('%Y-%m-%d %H:%M')}
    </div>
</div>
""", unsafe_allow_html=True)
